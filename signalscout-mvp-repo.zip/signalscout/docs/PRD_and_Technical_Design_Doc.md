# Product Requirements Document (PRD) & Technical Design Document

**Product Name:** SignalScout (Working Title)  
**Target Audience:** B2B Freelancers, Solo Consultants, Indie Hackers, Micro-SaaS Founders  
**Core Mission:** Convert real-time conversational pain signals on public social networks (Reddit, X, LinkedIn) into qualified leads with contextual, human-sounding outreach drafts—operating at $0 infrastructure cost during MVP bootstrap.

---

## 1. Product Requirements Document (PRD)

### 1.1 Executive Summary & Problem Definition
Small service providers and indie founders spend 5 to 15 hours per week manually searching social platforms for prospective clients or paying $150–$1,000+/month for enterprise tools (AiSDR, Traxy, Apollo). Enterprise tools rely on cold databases or aggressive automated messaging that risks platform bans and burns domain reputation.

SignalScout monitors public discussions where potential buyers explicitly state their pain points or complain about existing competitors. It scores their buying intent and drafts a hyper-personalized, non-salesy message that the user can review and send with one click.

### 1.2 Target Personas & Primary Use Cases
* **Solo Technical Consultant / Freelancer (e.g., Next.js / Shopify / DevOps):** Needs 2–3 high-ticket clients per quarter. Wants immediate alerts when a founder posts *"Our Shopify store crashed during launch"* or *"Need a Next.js contractor for 3 weeks"*.
* **Micro-SaaS Founder:** Wants to acquire users from dissatisfied competitor customers (e.g., monitoring *"Traxy alternative"* or *"Typeform is too expensive"*).
* **Niche Agency Owner (e.g., Cold Email / SEO):** Looks for prospects actively asking for agency recommendations or venting about poor marketing results.

### 1.3 Key User Journeys
1. **Zero-Configuration Onboarding (60 Seconds):**
   * The user enters their product or service landing page URL (or a 2-sentence plain text summary).
   * The system extracts: Value Proposition, Target Audience, 5 Direct Competitors, 10 High-Intent Trigger Keywords, and 10 Negative Filter Keywords.
   * The user reviews, toggles tags on/off, and clicks "Activate Monitor".
2. **Instant Retrospective Feed (The "Aha!" Moment):**
   * On submission, the system pulls the last 48 hours of matching public signals across Reddit and web-indexed social posts.
   * Within 20 seconds, the user sees 3 to 7 verified, scored leads instead of an empty dashboard.
3. **Daily Action Loop:**
   * At 08:00 AM local time, the user receives an email or Slack ping with the top 3 highest-scoring leads.
   * Each lead card provides the exact quote, source thread link, poster handle, and 3 distinct reply drafts (Helpful Peer, Direct DM, Value Question).
   * The user clicks "Copy Draft", opens the source link, and posts the reply in under 30 seconds.

### 1.4 Feature Matrix & Acceptance Criteria

| Feature ID | Feature Name | Description | Acceptance Criteria |
| :--- | :--- | :--- | :--- |
| **F-01** | AI ICP Profiler | Auto-infers monitoring rules from URL/text. | Must extract ≥5 pain keywords, ≥3 competitors, and ≥5 negative keywords with valid JSON. |
| **F-02** | Reddit Signal Ingestion | Ingests new submissions and top comments from target subreddits. | Deduplicates posts via SHA-256; processes incoming items within 30 minutes. |
| **F-03** | Web/Social Search Proxy | Ingests public X and LinkedIn mentions via search dorks. | Returns canonical source URLs; handles rate limits gracefully with backoff. |
| **F-04** | Two-Tier Intent Scorer | Classifies posts (Noise vs. Lead) and scores intent (1–100). | Low-cost tier discards ≥80% noise; high-intent tier outputs intent category & summary. |
| **F-05** | Contextual Reply Studio | Generates 3 tailored outreach styles based on user's offer. | Banned phrase validation (zero generic marketing clichés like "Hope this finds you well"). |
| **F-06** | Signal Delivery & Export | Delivers via Web UI, Daily Email Digest, and Slack Webhook. | Email delivered via transactional provider; webhooks fire within 60s of lead qualification. |
| **F-07** | Negative Feedback Loop | "Bad Lead" action button to tune user preferences. | User-flagged attributes dynamically appended to negative prompt context array. |

### 1.5 Anti-Features (Strictly Out of Scope for MVP)
* **No Automated Direct Messaging or Auto-Replying:** Protects user accounts from platform bans; maintains human-in-the-loop credibility.
* **No Private Cookie Scraping:** No requesting session tokens (`li_at`, `auth_token`). Public data only.
* **No Complex Drip Campaign Builders:** No automated multi-week email sequences.
* **No Team/Enterprise Permissions:** Single-seat accounts only.

---

## 2. Technical Architecture & Design Document

### 2.1 System Architecture Diagram

```
                       +-------------------------------------------------+
                       |              Public Data Ingestion              |
                       |  - Reddit JSON / OAuth API (Subreddits & Query) |
                       |  - Google Custom Search Dorks (X & LinkedIn)    |
                       +------------------------+------------------------+
                                                |
                                                v
                       +-------------------------------------------------+
                       |            Scheduled Job & Queue Worker         |
                       |       (Inngest Cloud / GitHub Actions Cron)     |
                       |  - Deduplication: SHA-256(platform + post_id)   |
                       |  - Normalization: Raw text, Author, Timestamp   |
                       +------------------------+------------------------+
                                                |
                                                v
                       +-------------------------------------------------+
                       |            Two-Tier AI Processing               |
                       |  Stage 1: Gemini 1.5 Flash (Noise Filter)       |
                       |           Is this post seeking a solution/tool? |
                       |  Stage 2: Gemini 1.5 Flash (Scoring & Drafting) |
                       |           Intent Score, Pain Point, 3 Drafts    |
                       +------------------------+------------------------+
                                                |
                                                v
                       +-------------------------------------------------+
                       |          Database & Persistence (Supabase)      |
                       |  - PostgreSQL (Profiles, Trackers, Leads, DDL)  |
                       |  - Row Level Security (RLS) & Auth              |
                       +------------------------+------------------------+
                                                |
                         +----------------------+----------------------+
                         |                                             |
                         v                                             v
         +-------------------------------+             +-------------------------------+
         |    Web Dashboard (Next.js)    |             |    Alerts & Transactional     |
         |  - Vercel Free Tier           |             |  - Resend (Daily Email Digest)|
         |  - shadcn/ui + Tailwind CSS   |             |  - Outbound Slack Webhook     |
         +-------------------------------+             +-------------------------------+
```

---

### 2.2 $0 Free-Tier Tech Stack & Quota Strategy

Every component is selected to operate entirely within its permanent free tier during initial development and early traction:

| Layer | Service / Tool | Free Tier Quota Allowance | Production Strategy & Mitigation |
| :--- | :--- | :--- | :--- |
| **Hosting & Frontend** | **Vercel** | 100 GB Bandwidth, Edge Functions | Next.js 15 App Router, static generation where possible. |
| **Database & Auth** | **Supabase** | 500 MB Postgres, 50,000 MAU, Auth | RLS policies enabled; auto-prune non-lead raw posts after 7 days. |
| **LLM Inference** | **Google Gemini 1.5 Flash** | 15 RPM, 1,500 RPD, 1M TPM (Free API) | Batched requests, prompt caching, JSON mode schema enforcement. |
| **Cron & Job Queue** | **Inngest Cloud** | 25,000 runs/month | 30-min polling intervals; batch process 25 posts per step. |
| **Reddit Ingestion** | **Reddit Developer API** | 100 queries/minute (Free Script App) | Query high-yield subreddits (`r/SaaS`, `r/webdev`, `r/freelance`). |
| **Social Web Search** | **Google Custom Search API** | 100 free search queries/day | Targeted site dorks: `site:x.com/status` and `site:linkedin.com/posts`. |
| **Email Delivery** | **Resend** | 100 emails/day, 3,000 emails/month | Combined daily morning digests; single notification per user/day. |
| **Alerts & Exports** | **Discord / Slack Webhooks** | Unlimited free incoming webhooks | Instant push notifications for leads scoring >85/100. |
| **Payments** | **Stripe Billing** | $0/mo base (Pay-as-you-transact: 2.9% + 30¢) | Customer portal + hosted checkout sessions. |

---

### 2.3 Database Schema (PostgreSQL DDL)

```sql
-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- 1. User Profiles & Monitored Offers
create table public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    email text not null,
    full_name text,
    business_name text,
    business_url text,
    offer_summary text,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Monitoring Trackers (Watchlists)
create table public.watchlists (
    id uuid primary key default uuid_generate_v4(),
    user_id uuid references public.profiles(id) on delete cascade not null,
    title text not null,
    target_audiences text[] not null default '{}',
    competitors text[] not null default '{}',
    keywords text[] not null default '{}',
    negative_keywords text[] not null default '{}',
    target_subreddits text[] not null default '{}',
    is_active boolean default true not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Raw Discovered Posts (Deduplication Buffer)
create table public.raw_posts (
    id uuid primary key default uuid_generate_v4(),
    source_platform text not null check (source_platform in ('reddit', 'x', 'linkedin')),
    external_id text not null,
    source_url text not null,
    author_handle text,
    post_title text,
    post_body text not null,
    published_at timestamp with time zone not null,
    dedup_hash text unique not null, -- sha256(source_platform || ':' || external_id)
    processed boolean default false not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index idx_raw_posts_dedup on public.raw_posts(dedup_hash);
create index idx_raw_posts_unprocessed on public.raw_posts(processed) where processed = false;

-- 4. Qualified Scored Leads
create type lead_status as enum ('new', 'contacted', 'saved', 'dismissed');
create type intent_category as enum ('competitor_complaint', 'vendor_seeking', 'advice_problem', 'general_pain');

create table public.qualified_leads (
    id uuid primary key default uuid_generate_v4(),
    watchlist_id uuid references public.watchlists(id) on delete cascade not null,
    user_id uuid references public.profiles(id) on delete cascade not null,
    raw_post_id uuid references public.raw_posts(id) on delete set null,
    intent_score integer not null check (intent_score between 1 and 100),
    intent_category intent_category not null,
    extracted_pain_point text not null,
    highlighted_quote text not null,
    draft_public_reply text not null,
    draft_private_dm text not null,
    draft_question text not null,
    status lead_status default 'new' not null,
    feedback_reason text,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index idx_leads_user_status on public.qualified_leads(user_id, status);

-- Enable Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.watchlists enable row level security;
alter table public.qualified_leads enable row level security;

-- RLS Policies
create policy "Users manage own profile" on public.profiles
    for all using (auth.uid() = id);

create policy "Users manage own watchlists" on public.watchlists
    for all using (auth.uid() = user_id);

create policy "Users manage own leads" on public.qualified_leads
    for all using (auth.uid() = user_id);
```

---

### 2.4 Data Ingestion Specifications

#### A. Reddit Collector (Free Tier: Script App OAuth)
* **Auth Endpoint:** `https://www.reddit.com/api/v1/access_token` (`grant_type=client_credentials`).
* **Ingestion Logic:**
  1. Poll subreddits defined in active watchlists (e.g., `https://oauth.reddit.com/r/{sub}/new?limit=25`).
  2. For broad keywords, use search: `https://oauth.reddit.com/r/{sub}/search?q="{keyword}"&sort=new&t=day&restrict_sr=1`.
  3. Extract `id`, `author`, `title`, `selftext`, `permalink`, `created_utc`.
  4. Generate `dedup_hash = sha256("reddit:" + id)`.
  5. Bulk insert with `ON CONFLICT (dedup_hash) DO NOTHING`.

#### B. Public Social Search Collector (Free Tier: Google Custom Search Engine)
* **Query Dorks:**
  * X/Twitter: `site:x.com/*/status/* ("looking for a" OR "recommend a" OR "switch from {competitor}") "{topic}"`
  * LinkedIn: `site:linkedin.com/posts/* ("looking for" OR "anyone know a" OR "hiring a freelancer for") "{topic}"`
* **Execution Interval:** Scheduled once every 6 hours (4 queries/day × 5 niches = 20 queries/day, well within the 100 free query/day quota).
* **Normalization:** Extract URL snippet, title, and timestamp; store into `public.raw_posts`.

---

### 2.5 Two-Tier LLM Intelligence Pipeline

To stay strictly within the Gemini 1.5 Flash free rate limits (15 RPM / 1,500 RPD), the pipeline uses a two-tier filter.

#### Tier 1: Fast Noise Gate (Binary Classifier)
* **Model:** Gemini 1.5 Flash (`temperature: 0.1`, `max_output_tokens: 30`)
* **Execution:** Evaluates batches of 10 posts simultaneously in a single prompt.
* **System Prompt:**
```text
You are a strict data classifier. Determine if each social post is a genuine potential buyer expressing a problem, seeking software/service recommendations, or complaining about a competitor.
Exclude: Job seekers looking for employment, sales reps promoting products, course advertisements, tutorials, and general discussions.
Return JSON strictly in the format: [{"id": "...", "is_lead": true/false}]
```
* **Cost Impact:** Filters out 85%+ of irrelevant chatter without wasting tokens on drafting.

#### Tier 2: Deep Extraction & Contextual Outreach Studio
* **Model:** Gemini 1.5 Flash (`temperature: 0.3`, `response_mime_type: "application/json"`)
* **Trigger:** Only executed for posts flagged `is_lead: true`.
* **Prompt Template:**
```text
SYSTEM:
You are an expert sales strategist who writes organic, non-cringe outreach messages for boutique service providers and founders.
You strictly adhere to conversational realism:
1. Never use corporate buzzwords or generic greetings ("Hope you're well", "I came across your post and couldn't resist reaching out").
2. Reference the exact detail, obstacle, or tool the author mentioned.
3. Keep public replies focused on solving their issue in public, without a hard sales pitch.
4. Keep private DMs brief (under 50 words), low friction, and easy to decline.

CONTEXT:
User Offer: {{watchlist.offer_summary}}
Target Competitors: {{watchlist.competitors}}
Relevant Keywords: {{watchlist.keywords}}

PROSPECT POST:
Platform: {{raw_post.source_platform}}
Author: {{raw_post.author_handle}}
Text: {{raw_post.post_body}}

OUTPUT SCHEMA (JSON):
{
  "intent_score": <Integer between 1 and 100>,
  "intent_category": "competitor_complaint" | "vendor_seeking" | "advice_problem" | "general_pain",
  "extracted_pain_point": "<Max 12 words summarizing the core frustration>",
  "highlighted_quote": "<Exact verbatim sentence from post showing intent>",
  "draft_public_reply": "<Helpful, insightful 2-3 sentence comment adding value>",
  "draft_private_dm": "<Casual 2-sentence DM acknowledging their specific post and offering a direct case study/fix>",
  "draft_question": "<A sharp diagnostic question uncovering more about their current bottleneck>"
}
```

---

### 2.6 Background Job Flow (Inngest Worker Example)

```typescript
// inngest/functions/process-leads.ts
import { inngest } from "./client";
import { supabaseAdmin } from "@/lib/supabase";
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export const processIncomingPosts = inngest.createFunction(
  { id: "process-incoming-social-posts" },
  { cron: "*/30 * * * *" }, // Run every 30 minutes
  async ({ step }) => {
    // 1. Fetch unprocessed raw posts
    const posts = await step.run("fetch-unprocessed-posts", async () => {
      const { data } = await supabaseAdmin
        .from("raw_posts")
        .select("*")
        .eq("processed", false)
        .order("created_at", { ascending: false })
        .limit(20);
      return data || [];
    });

    if (posts.length === 0) return { message: "No new posts to process" };

    // 2. Run Tier 1 Noise Filter
    const qualifiedPostIds = await step.run("run-tier-1-filter", async () => {
      // Calls Gemini 1.5 Flash batch classifier
      return filterNoiseWithGemini(posts);
    });

    // 3. For qualified posts, run Tier 2 Deep Extraction against active watchlists
    await step.run("run-tier-2-deep-extraction", async () => {
      for (const postId of qualifiedPostIds) {
        const post = posts.find((p) => p.id === postId);
        if (!post) continue;

        const watchlists = await getMatchingWatchlists(post);
        for (const wl of watchlists) {
          const leadData = await generateOutreachWithGemini(post, wl);
          if (leadData.intent_score >= 60) {
            await supabaseAdmin.from("qualified_leads").insert({
              watchlist_id: wl.id,
              user_id: wl.user_id,
              raw_post_id: post.id,
              ...leadData,
            });
            // Fire Slack webhook if high score (>85)
            if (leadData.intent_score >= 85 && wl.slack_webhook_url) {
              await sendSlackAlert(wl.slack_webhook_url, leadData, post);
            }
          }
        }
      }
    });

    // 4. Mark posts as processed
    await step.run("mark-posts-processed", async () => {
      const ids = posts.map((p) => p.id);
      await supabaseAdmin.from("raw_posts").update({ processed: true }).in("id", ids);
    });
  }
);
```

---

### 2.7 Frontend UI/UX Structure

```
app/
├── (auth)/
│   ├── login/page.tsx           # Supabase Auth UI (Magic Link + Google OAuth)
│   └── callback/route.ts        # Auth exchange route
├── (dashboard)/
│   ├── layout.tsx               # Sidebar navigation, User profile, Plan status
│   ├── page.tsx                 # Main Leads Feed (Filters: Urgency, Status, Platform)
│   ├── watchlists/
│   │   ├── page.tsx             # Active Trackers table
│   │   └── new/page.tsx         # AI Onboarding Wizard (URL/Text -> Generated keywords)
│   └── settings/
│       ├── page.tsx             # Notification preferences (Email digest, Slack webhook)
│       └── billing/page.tsx      # Stripe Customer Portal redirect button
└── api/
    └── webhooks/
        └── stripe/route.ts      # Subscription status syncing
```

#### Key Lead Card UI Anatomy
1. **Header:** Source Icon (`Reddit` / `X` / `LinkedIn`), Author handle, Time elapsed, Intent Category Badge.
2. **Body:** 
   * Verbatim Quote (italicized, highlighted in subtle yellow/amber background).
   * Context expander showing full original post text.
3. **Outreach Tab Switcher:**
   * Tab 1: Public Reply (Default)
   * Tab 2: Private DM
   * Tab 3: Diagnostic Question
4. **Action Bar:**
   * `[Copy Draft]` button (Copies selected tab text, shows toast).
   * `[Open Post ↗]` button (Opens target URL in new tab; automatically updates status to "Contacted").
   * `[Dismiss / Bad Lead]` dropdown (Options: "Wrong audience", "Job seeker", "Spam" -> updates user's negative keyword array).

---

### 2.8 Security, Platform Compliance & Ban-Proofing Architecture

1. **Zero Session Impersonation:**
   * Traditional scrapers require users to paste session cookies (`li_at` for LinkedIn, `auth_token` for X). When automated from server IP addresses, these accounts are flagged and permanently banned.
   * SignalScout interacts **only** with public data endpoints (Reddit public API and Google web search indexes). It never authenticates as the user on third-party social networks.
2. **Zero Automated Contact:**
   * Outreach sending is strictly client-side. The user clicks `Open Post` and posts the comment from their own personal browser session. This completely insulates the backend from anti-spam regulations (CAN-SPAM, GDPR) and platform ToS violations.
3. **Data Retention & Privacy:**
   * Raw posts that are scored as noise (`is_lead: false`) are permanently deleted after 7 days to maintain database lean margins and respect user privacy.

---

### 2.9 4-Week Zero-Dollar Implementation Sprint

#### Week 1: Ingestion & Storage Scaffold ($0 Cost)
* Set up free Supabase project, execute schema migrations, configure Row Level Security.
* Create Reddit Developer Script app; build TypeScript ingestion script fetching top 25 submissions across 5 subreddits.
* Set up Google Custom Search Engine (free tier) for target search dorks.
* Validate SHA-256 deduplication pipeline locally.

#### Week 2: AI Intent Engine & Scoring ($0 Cost)
* Get free Gemini API key from Google AI Studio.
* Implement Tier 1 binary noise classifier; benchmark against 100 real Reddit posts (aim for >85% precision).
* Implement Tier 2 structured JSON output for intent scoring and outreach drafting.
* Build negative-keyword array updater based on dismissed leads.

#### Week 3: Frontend & Dashboard Delivery ($0 Cost)
* Scaffold Next.js 15 App Router with Tailwind and shadcn/ui on Vercel Hobby.
* Build 60-Second Onboarding Wizard: takes URL, calls Gemini to extract keywords, saves watchlist.
* Build Responsive Lead Feed with 1-click clipboard actions and status filters.
* Connect Inngest Cloud (free tier) to run the 30-minute ingestion cron.

#### Week 4: Alerting, Stripe & Launch ($0 Cost)
* Connect Resend (free tier) to dispatch the daily 08:00 AM summary email digest.
* Add Slack Webhook integration for instant notifications.
* Connect Stripe in test mode, set up $39/mo and $79/mo subscription plans.
* Seed your own account with 3 monitor profiles, dogfood on live leads, and publish the project for the Google Buildathon.
