-- ============================================================================
-- SignalScout Initial Database Schema (PostgreSQL / Supabase)
-- ============================================================================

create extension if not exists "uuid-ossp";

-- 1. User Profiles & Monitored Offers
create table public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    email text not null,
    full_name text,
    business_name text,
    business_url text,
    offer_summary text,
    subscription_tier text default 'free' not null check (subscription_tier in ('free', 'starter', 'pro')),
    stripe_customer_id text,
    daily_digest_enabled boolean default true not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Monitoring Trackers (Watchlists)
create table public.watchlists (
    id uuid primary key default uuid_generate_v4(),
    user_id uuid references public.profiles(id) on delete cascade not null,
    title text not null,
    offer_summary text not null,
    target_audiences text[] not null default '{}',
    competitors text[] not null default '{}',
    keywords text[] not null default '{}',
    negative_keywords text[] not null default '{}',
    target_subreddits text[] not null default '{}',
    slack_webhook_url text,
    is_active boolean default true not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Raw Discovered Posts (Deduplication Buffer)
create table public.raw_posts (
    id uuid primary key default uuid_generate_v4(),
    source_platform text not null check (source_platform in ('reddit', 'x', 'linkedin')),
    external_id text not null,
    source_url text not null,
    author_handle text,
    subreddit text,
    post_title text,
    post_body text not null,
    published_at timestamp with time zone not null,
    dedup_hash text unique not null, -- sha256(source_platform || ':' || external_id)
    processed boolean default false not null,
    is_noise boolean default false not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index idx_raw_posts_dedup on public.raw_posts(dedup_hash);
create index idx_raw_posts_unprocessed on public.raw_posts(processed) where processed = false;
create index idx_raw_posts_created_at on public.raw_posts(created_at);

-- 4. Qualified Scored Leads
create type lead_status as enum ('new', 'contacted', 'saved', 'dismissed');
create type intent_category as enum ('competitor_complaint', 'vendor_seeking', 'advice_problem', 'general_pain');

create table public.qualified_leads (
    id uuid primary key default uuid_generate_v4(),
    watchlist_id uuid references public.watchlists(id) on delete cascade not null,
    user_id uuid references public.profiles(id) on delete cascade not null,
    raw_post_id uuid references public.raw_posts(id) on delete cascade not null,
    intent_score integer not null check (intent_score between 1 and 100),
    intent_category intent_category not null,
    extracted_pain_point text not null,
    highlighted_quote text not null,
    draft_public_reply text not null,
    draft_private_dm text not null,
    draft_question text not null,
    status lead_status default 'new' not null,
    feedback_reason text,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index idx_leads_user_status on public.qualified_leads(user_id, status);
create index idx_leads_score on public.qualified_leads(intent_score desc);

-- 5. Enable Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.watchlists enable row level security;
alter table public.qualified_leads enable row level security;

create policy "Users manage own profile" on public.profiles
    for all using (auth.uid() = id);

create policy "Users manage own watchlists" on public.watchlists
    for all using (auth.uid() = user_id);

create policy "Users manage own leads" on public.qualified_leads
    for all using (auth.uid() = user_id);

-- 6. Helper function to prune 7-day-old noise posts (Keeps Free 500MB Supabase DB clean)
create or replace function public.prune_old_noise_posts()
returns integer
language plpgsql
security definer
as $$
declare
    deleted_count integer;
begin
    delete from public.raw_posts
    where processed = true
      and is_noise = true
      and created_at < now() - interval '7 days';
    get diagnostics deleted_count = row_count;
    return deleted_count;
end;
$$;
