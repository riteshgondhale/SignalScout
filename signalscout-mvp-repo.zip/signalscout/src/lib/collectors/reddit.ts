import crypto from "crypto";
import { RawPostInput } from "../gemini";

export function computeDedupHash(platform: string, externalId: string): string {
  return crypto
    .createHash("sha256")
    .update(`${platform}:${externalId}`)
    .digest("hex");
}

/**
 * Fetches latest submissions from target subreddits using either Reddit OAuth
 * or public JSON endpoints as fallback for zero-config local testing.
 */
export async function collectRedditSignals(
  subreddits: string[],
  keywords: string[]
): Promise<Array<RawPostInput & { dedup_hash: string; published_at: string; subreddit: string }>> {
  const results: Array<RawPostInput & { dedup_hash: string; published_at: string; subreddit: string }> = [];
  const userAgent =
    process.env.REDDIT_USER_AGENT || "SignalScout/0.1.0 (Open Source Social Intent Agent)";

  const cleanSubs = subreddits
    .map((s) => s.replace(/^r\//i, "").trim())
    .filter(Boolean)
    .slice(0, 6);

  for (const sub of cleanSubs) {
    try {
      const url = `https://www.reddit.com/r/${encodeURIComponent(sub)}/new.json?limit=20`;
      const response = await fetch(url, {
        headers: {
          "User-Agent": userAgent,
          Accept: "application/json",
        },
        next: { revalidate: 0 },
      });

      if (!response.ok) continue;

      const json = await response.json();
      const children = json?.data?.children || [];

      for (const child of children) {
        const post = child?.data;
        if (!post || !post.id) continue;

        const title = (post.title || "").trim();
        const selftext = (post.selftext || "").trim();
        const combinedText = `${title}\n\n${selftext}`.trim();

        // Skip empty link-only posts or tiny posts
        if (combinedText.length < 35) continue;

        // Optional lightweight keyword pre-check if keywords are provided
        const lowerText = combinedText.toLowerCase();
        const hasSignalCue =
          keywords.length === 0 ||
          keywords.some((kw) => lowerText.includes(kw.toLowerCase())) ||
          /\b(looking for|recommend|alternative|switching from|frustrated|too expensive|help with|anyone use|how do you handle|struggling)\b/i.test(
            combinedText
          );

        if (!hasSignalCue) continue;

        const externalId = String(post.id);
        const dedupHash = computeDedupHash("reddit", externalId);

        results.push({
          id: externalId,
          source_platform: "reddit",
          author_handle: post.author ? `u/${post.author}` : "u/anonymous",
          subreddit: `r/${sub}`,
          post_title: title,
          post_body: selftext || title,
          source_url: `https://www.reddit.com${post.permalink}`,
          dedup_hash: dedupHash,
          published_at: new Date((post.created_utc || Date.now() / 1000) * 1000).toISOString(),
        });
      }
    } catch (err) {
      console.error(`[Reddit Collector] Failed fetching r/${sub}:`, err);
    }
  }

  return results;
}
