import { computeDedupHash } from "./reddit";
import { RawPostInput } from "../gemini";

/**
 * Uses Google Custom Search JSON API (Free Tier: 100 queries/day) to discover
 * public high-intent posts on X (Twitter) and LinkedIn without session cookies or account bans.
 */
export async function collectSocialSearchSignals(
  competitors: string[],
  keywords: string[]
): Promise<Array<RawPostInput & { dedup_hash: string; published_at: string }>> {
  const apiKey = process.env.GOOGLE_CSE_API_KEY;
  const cx = process.env.GOOGLE_CSE_CX;

  if (!apiKey || !cx) {
    return [];
  }

  const results: Array<RawPostInput & { dedup_hash: string; published_at: string }> = [];
  const primaryTopic = keywords[0] || competitors[0] || "SaaS";
  const compClause =
    competitors.length > 0
      ? `OR "${competitors.slice(0, 2).join('" OR "')}"`
      : "";

  const dorks: Array<{ platform: "x" | "linkedin"; query: string }> = [
    {
      platform: "x",
      query: `site:x.com/*/status/* ("looking for" OR "alternative to" OR "recommend a" ${compClause}) "${primaryTopic}"`,
    },
    {
      platform: "linkedin",
      query: `site:linkedin.com/posts/* ("looking for a" OR "anyone recommend" OR "switching from" ${compClause}) "${primaryTopic}"`,
    },
  ];

  for (const dork of dorks) {
    try {
      const url = new URL("https://www.googleapis.com/customsearch/v1");
      url.searchParams.set("key", apiKey);
      url.searchParams.set("cx", cx);
      url.searchParams.set("q", dork.query);
      url.searchParams.set("sort", "date"); // Most recent indexed signals
      url.searchParams.set("num", "10");

      const response = await fetch(url.toString());
      if (!response.ok) continue;

      const data = await response.json();
      const items = data?.items || [];

      for (const item of items) {
        const link: string = item.link || "";
        const snippet: string = item.snippet || "";
        const title: string = item.title || "";

        if (!link || snippet.length < 30) continue;

        const externalId = Buffer.from(link).toString("base64url").slice(-32);
        const dedupHash = computeDedupHash(dork.platform, externalId);

        // Extract author handle from URL or title where possible
        let authorHandle = dork.platform === "x" ? "@x_user" : "LinkedIn Member";
        if (dork.platform === "x") {
          const match = link.match(/x\.com\/([^/]+)\/status/);
          if (match?.[1]) authorHandle = `@${match[1]}`;
        } else if (dork.platform === "linkedin") {
          const match = title.split("|")[0]?.trim();
          if (match) authorHandle = match;
        }

        results.push({
          id: externalId,
          source_platform: dork.platform,
          author_handle: authorHandle,
          post_title: title,
          post_body: snippet,
          source_url: link,
          dedup_hash: dedupHash,
          published_at: new Date().toISOString(),
        });
      }
    } catch (err) {
      console.error(`[Social Search Collector] Error querying ${dork.platform}:`, err);
    }
  }

  return results;
}
