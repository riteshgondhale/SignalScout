import { GoogleGenerativeAI, SchemaType } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export interface RawPostInput {
  id: string;
  source_platform: "reddit" | "x" | "linkedin";
  author_handle: string;
  post_title?: string;
  post_body: string;
  source_url: string;
}

export interface WatchlistConfig {
  id: string;
  user_id: string;
  title: string;
  offer_summary: string;
  target_audiences: string[];
  competitors: string[];
  keywords: string[];
  negative_keywords: string[];
  target_subreddits: string[];
  slack_webhook_url?: string | null;
}

export interface QualifiedLeadOutput {
  intent_score: number;
  intent_category: "competitor_complaint" | "vendor_seeking" | "advice_problem" | "general_pain";
  extracted_pain_point: string;
  highlighted_quote: string;
  draft_public_reply: string;
  draft_private_dm: string;
  draft_question: string;
}

export interface GeneratedWatchlistProfile {
  title: string;
  offer_summary: string;
  target_audiences: string[];
  competitors: string[];
  keywords: string[];
  negative_keywords: string[];
  target_subreddits: string[];
}

/**
 * 60-Second Onboarding Profiler:
 * Converts a user's URL or 2-sentence description into a complete monitoring profile.
 */
export async function generateWatchlistFromInput(
  userInput: string
): Promise<GeneratedWatchlistProfile> {
  const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: {
      temperature: 0.2,
      responseMimeType: "application/json",
      responseSchema: {
        type: SchemaType.OBJECT,
        properties: {
          title: { type: SchemaType.STRING },
          offer_summary: { type: SchemaType.STRING },
          target_audiences: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
          competitors: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
          keywords: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
          negative_keywords: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
          target_subreddits: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
        },
        required: [
          "title",
          "offer_summary",
          "target_audiences",
          "competitors",
          "keywords",
          "negative_keywords",
          "target_subreddits",
        ],
      },
    },
  });

  const prompt = `You are a B2B social intent strategist. Given the following product, service, or website description, generate a high-signal social listening configuration.

USER INPUT:
"${userInput}"

Requirements:
- title: Short 2-4 word label for this monitor (e.g., "Shopify Speed Consulting" or "Micro-SaaS Billing").
- offer_summary: Clear 1-2 sentence value proposition.
- target_audiences: 4-6 specific buyer personas/roles.
- competitors: 5-8 direct software or agency alternatives people might complain about.
- keywords: 8-12 conversational phrases buyers use when seeking help (e.g., "looking for a", "alternative to", "struggling with", "recommend a tool for").
- negative_keywords: 6-10 filter terms to block job seekers, spammers, courses, or irrelevant chatter (e.g., "hiring intern", "my course", "looking for job", "[for hire]").
- target_subreddits: 5-8 active subreddit names WITHOUT the "r/" prefix (e.g., "SaaS", "entrepreneur", "webdev", "smallbusiness", "shopify").`;

  const result = await model.generateContent(prompt);
  return JSON.parse(result.response.text()) as GeneratedWatchlistProfile;
}

/**
 * TIER 1: Fast Binary Noise Gate
 * Processes up to 15 posts in a single call to conserve Gemini Free Tier RPM (15 RPM).
 * Filters out >85% of self-promotion, job seekers, and low-value chatter.
 */
export async function filterNoiseBatch(
  posts: RawPostInput[]
): Promise<string[]> {
  if (posts.length === 0) return [];

  const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: {
      temperature: 0.1,
      responseMimeType: "application/json",
      responseSchema: {
        type: SchemaType.ARRAY,
        items: {
          type: SchemaType.OBJECT,
          properties: {
            id: { type: SchemaType.STRING },
            is_lead: { type: SchemaType.BOOLEAN },
          },
          required: ["id", "is_lead"],
        },
      },
    },
  });

  const compactPosts = posts.map((p) => ({
    id: p.id,
    platform: p.source_platform,
    title: p.post_title || "",
    text: p.post_body.slice(0, 600),
  }));

  const prompt = `You are a strict B2B buyer-intent filter. Evaluate each social post and set is_lead = true ONLY if the author is:
1. Expressing frustration with an existing software tool, agency, or workflow.
2. Asking for recommendations, tools, freelancers, or how to solve a specific business/technical problem.
3. Explicitly looking to switch from a competitor.

Set is_lead = false if the author is:
- Promoting their own product, service, agency, or "[For Hire]" post.
- Sharing a generic tutorial, case study, or humblebrag revenue post.
- Looking for a full-time job or internship.

POSTS TO EVALUATE:
${JSON.stringify(compactPosts)}`;

  const result = await model.generateContent(prompt);
  const parsed = JSON.parse(result.response.text()) as Array<{
    id: string;
    is_lead: boolean;
  }>;

  return parsed.filter((item) => item.is_lead).map((item) => item.id);
}

/**
 * TIER 2: Deep Intent Scoring & Anti-Slop Contextual Outreach Studio
 * Generates 3 natural, peer-level responses with strict anti-cliche guardrails.
 */
export async function scoreAndDraftOutreach(
  post: RawPostInput,
  watchlist: WatchlistConfig
): Promise<QualifiedLeadOutput> {
  const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: {
      temperature: 0.3,
      responseMimeType: "application/json",
      responseSchema: {
        type: SchemaType.OBJECT,
        properties: {
          intent_score: { type: SchemaType.INTEGER },
          intent_category: {
            type: SchemaType.STRING,
            enum: [
              "competitor_complaint",
              "vendor_seeking",
              "advice_problem",
              "general_pain",
            ],
          },
          extracted_pain_point: { type: SchemaType.STRING },
          highlighted_quote: { type: SchemaType.STRING },
          draft_public_reply: { type: SchemaType.STRING },
          draft_private_dm: { type: SchemaType.STRING },
          draft_question: { type: SchemaType.STRING },
        },
        required: [
          "intent_score",
          "intent_category",
          "extracted_pain_point",
          "highlighted_quote",
          "draft_public_reply",
          "draft_private_dm",
          "draft_question",
        ],
      },
    },
  });

  const prompt = `You are a senior B2B practitioner helping a founder or consultant reply to a high-intent social post.

STRICT ANTI-SLOP WRITING RULES:
1. NEVER use phrases like: "I hope this finds you well", "I stumbled upon your post", "thrilled to", "game-changer", "synergy", "delve", "let's hop on a quick call".
2. Write like an experienced peer on Reddit or X—concise, direct, lowercase-friendly where natural, and immediately useful.
3. Reference the exact technical detail, tool, or bottleneck the poster mentioned.
4. If the post matches any negative keywords (${watchlist.negative_keywords.join(", ")}), score intent_score below 25.

USER OFFER CONTEXT:
- Offer Summary: ${watchlist.offer_summary}
- Target Audience: ${watchlist.target_audiences.join(", ")}
- Monitored Competitors: ${watchlist.competitors.join(", ")}
- Target Keywords: ${watchlist.keywords.join(", ")}

SOCIAL POST:
- Platform: ${post.source_platform}
- Author: ${post.author_handle}
- Title: ${post.post_title || "(No title)"}
- Body: ${post.post_body}

OUTPUT INSTRUCTIONS:
- intent_score: 1-100 based on urgency, relevance to User Offer, and buying authority.
- extracted_pain_point: Max 12 words summarizing their exact problem.
- highlighted_quote: Exact verbatim substring from the post proving intent.
- draft_public_reply: 2-3 sentences giving actionable advice directly in the thread without pitching or linking.
- draft_private_dm: Casual 2-sentence DM acknowledging their thread and offering a relevant fix or example (under 45 words).
- draft_question: 1-2 sentence diagnostic question to spark a reply in the comments.`;

  const result = await model.generateContent(prompt);
  return JSON.parse(result.response.text()) as QualifiedLeadOutput;
}
