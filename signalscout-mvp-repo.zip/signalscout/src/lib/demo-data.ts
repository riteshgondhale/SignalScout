export interface DemoLead {
  id: string;
  watchlist_id: string;
  source_platform: "reddit" | "x" | "linkedin";
  subreddit?: string;
  author_handle: string;
  published_ago: string;
  source_url: string;
  post_title: string;
  post_body: string;
  intent_score: number;
  intent_category: "competitor_complaint" | "vendor_seeking" | "advice_problem" | "general_pain";
  extracted_pain_point: string;
  highlighted_quote: string;
  draft_public_reply: string;
  draft_private_dm: string;
  draft_question: string;
  status: "new" | "contacted" | "saved" | "dismissed";
}

export const INITIAL_DEMO_LEADS: DemoLead[] = [
  {
    id: "lead-001",
    watchlist_id: "wl-default",
    source_platform: "reddit",
    subreddit: "r/SaaS",
    author_handle: "u/bootstrapped_dan",
    published_ago: "18m ago",
    source_url: "https://www.reddit.com/r/SaaS",
    post_title: "Burning $399/mo on Traxy and Apollo—still spending 2 hours filtering junk leads",
    post_body:
      "We run a 3-person B2B consultancy. Tried Apollo cold lists (abysmal reply rate) and recently tried Traxy.ai for LinkedIn signals, but $399/mo is steep when half our buyers actually hang out on Reddit and X talking about technical migrations. Is there a lightweight tool that just monitors Reddit + X + LinkedIn for buying intent and drafts replies without trying to be a full autonomous AI SDR?",
    intent_score: 96,
    intent_category: "competitor_complaint",
    extracted_pain_point: "Paying $399/mo for LinkedIn-only tools; wants multi-platform warm signals",
    highlighted_quote:
      "Is there a lightweight tool that just monitors Reddit + X + LinkedIn for buying intent and drafts replies without trying to be a full autonomous AI SDR?",
    draft_public_reply:
      "Cold lists have been rough this year unless your domain warmup is spotless. For Reddit and X, the highest-converting flow we've seen is tracking specific problem phrases ('migrating away from', 'too slow') rather than broad job titles, then replying directly in-thread before DMing.",
    draft_private_dm:
      "Saw your post in r/SaaS about Traxy's pricing and needing Reddit/X signals. We built a lightweight monitor that pulls live intent threads across Reddit, X, and LinkedIn with pre-drafted replies for $39/mo—happy to send you a free workspace link if you want to test it on your migration keywords.",
    draft_question:
      "Which specific technical migration topics are giving you the highest close rate right now on Reddit vs LinkedIn?",
    status: "new",
  },
  {
    id: "lead-002",
    watchlist_id: "wl-default",
    source_platform: "x",
    author_handle: "@sarah_builds_dtc",
    published_ago: "42m ago",
    source_url: "https://x.com",
    post_title: "Shopify Checkout Extensibility migration breaking our bundle scripts",
    post_body:
      "Anyone have a reliable Shopify Plus dev or small specialist team? Our current agency quoted 6 weeks just to migrate our legacy checkout.liquid scripts to Checkout Extensibility and BFCM prep is right around the corner.",
    intent_score: 93,
    intent_category: "vendor_seeking",
    extracted_pain_point: "Urgent Shopify Plus Checkout Extensibility migration needed before BFCM",
    highlighted_quote:
      "Anyone have a reliable Shopify Plus dev or small specialist team? Our current agency quoted 6 weeks just to migrate our legacy checkout.liquid scripts",
    draft_public_reply:
      "6 weeks for checkout.liquid to Extensibility is definitely padded unless you have custom ERP webhooks firing mid-checkout. Most bundle script replacements can be mapped cleanly to Shopify Functions in 5-7 days if you decouple the UI extensions first.",
    draft_private_dm:
      "Hey Sarah, saw your tweet on the checkout.liquid migration bottleneck. I've migrated 11 Shopify Plus stores to Functions + Checkout UI Extensions this quarter in under 10 days—can take a quick look at your bundle logic today if helpful.",
    draft_question:
      "Are your bundle scripts purely discount-tier logic, or are they injecting custom line-item properties at checkout?",
    status: "new",
  },
  {
    id: "lead-003",
    watchlist_id: "wl-default",
    source_platform: "linkedin",
    author_handle: "Marcus Vance (VP Growth @ FinStack)",
    published_ago: "1h ago",
    source_url: "https://www.linkedin.com",
    post_title: "Stopped using automated LinkedIn DM bots after account restriction warning",
    post_body:
      "Hard lesson learned this week: hooked up an AI SDR tool that asked for my LinkedIn session cookie to automate connection requests and sequences. Got hit with a temporary account restriction within 72 hours. Going back to manual outreach, just need a faster way to spot who is actually discussing revops bottlenecks.",
    intent_score: 89,
    intent_category: "competitor_complaint",
    extracted_pain_point: "Got restricted from cookie-based AI SDR; wants ban-proof manual signal discovery",
    highlighted_quote:
      "Going back to manual outreach, just need a faster way to spot who is actually discussing revops bottlenecks.",
    draft_public_reply:
      "Session cookie scraping from datacenter IPs is an instant flag on LinkedIn now. Keeping the final send human-in-the-loop from your own browser takes 20 seconds per lead and gets 3x better reply rates anyway because you aren't blasting templates.",
    draft_private_dm:
      "Marcus — read your post on the LinkedIn session cookie warning. We built SignalScout specifically with zero cookie scraping (public index monitoring only + 1-click copy/paste replies) so your account stays 100% safe. Happy to share how we track RevOps intent signals.",
    draft_question:
      "When you do manual outreach now, are you mostly tracking competitor mentions or specific RevOps tooling questions?",
    status: "new",
  },
  {
    id: "lead-004",
    watchlist_id: "wl-default",
    source_platform: "reddit",
    subreddit: "r/webdev",
    author_handle: "u/kyle_saas_cto",
    published_ago: "2h ago",
    source_url: "https://www.reddit.com/r/webdev",
    post_title: "Need a fractional Next.js + Supabase architect to audit our multi-tenant RLS before SOC2",
    post_body:
      "We scaled our MVP to 40 B2B customers on Next.js 15 + Supabase, but our enterprise prospects are asking for tenant isolation proofs and our RLS policies are a mess of nested joins killing query performance. Looking for someone who has done this before for a 2-week paid engagement.",
    intent_score: 91,
    intent_category: "vendor_seeking",
    extracted_pain_point: "Hiring fractional Next.js + Supabase expert for 2-week RLS & SOC2 audit",
    highlighted_quote:
      "Looking for someone who has done this before for a 2-week paid engagement.",
    draft_public_reply:
      "Nested joins inside RLS `USING` clauses force Postgres to evaluate the subquery per row unless you wrap security-definer helpers or move org_id into `auth.jwt() -> app_metadata`. Moving tenant claims into JWT custom claims usually drops query latency by 80%+ immediately.",
    draft_private_dm:
      "Hey Kyle, saw your r/webdev thread on the Supabase multi-tenant RLS bottlenecks. I recently helped two B2B SaaS teams refactor their RLS to JWT app_metadata claims for SOC2 readiness—have availability this week for a 2-week sprint if you're still looking.",
    draft_question:
      "Are you currently storing tenant membership in a join table queried inside every RLS policy, or passing org_id in JWT app_metadata?",
    status: "new",
  },
];
