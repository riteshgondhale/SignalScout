import { Inngest } from "inngest";
import { supabaseAdmin, isSupabaseConfigured } from "@/lib/supabase";
import { collectRedditSignals } from "@/lib/collectors/reddit";
import { collectSocialSearchSignals } from "@/lib/collectors/social-search";
import {
  filterNoiseBatch,
  scoreAndDraftOutreach,
  WatchlistConfig,
} from "@/lib/gemini";

export const inngest = new Inngest({ id: "signalscout-app" });

/**
 * Helper to fire instant Slack / Discord incoming webhook for high-intent leads (score >= 85)
 */
async function sendInstantWebhookAlert(
  webhookUrl: string,
  lead: {
    intent_score: number;
    intent_category: string;
    extracted_pain_point: string;
    highlighted_quote: string;
    draft_public_reply: string;
  },
  post: {
    source_platform: string;
    author_handle: string;
    source_url: string;
  }
) {
  try {
    await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: `🔥 *High-Intent Lead (${lead.intent_score}/100)* on *${post.source_platform.toUpperCase()}* (${post.author_handle})\n*Pain:* ${lead.extracted_pain_point}\n> "${lead.highlighted_quote}"\n*Suggested Reply:* ${lead.draft_public_reply}\n<${post.source_url}|Open Thread ↗>`,
      }),
    });
  } catch (err) {
    console.error("[Webhook Alert] Failed to notify webhook:", err);
  }
}

/**
 * 1. Scheduled 30-Minute Social Signal Ingestion & Two-Tier Gemini Processing
 */
export const processIncomingSocialSignals = inngest.createFunction(
  { id: "process-incoming-social-signals" },
  { cron: "*/30 * * * *" },
  async ({ step }) => {
    if (!isSupabaseConfigured()) {
      return { status: "skipped", reason: "Supabase not configured yet" };
    }

    // Step 1: Load active watchlists
    const watchlists = await step.run("fetch-active-watchlists", async () => {
      const { data } = await supabaseAdmin
        .from("watchlists")
        .select("*")
        .eq("is_active", true);
      return (data || []) as WatchlistConfig[];
    });

    if (watchlists.length === 0) {
      return { status: "idle", reason: "No active watchlists" };
    }

    // Step 2: Poll Reddit and Social Search Dorks
    const discoveredCount = await step.run("ingest-raw-signals", async () => {
      const allSubs = Array.from(
        new Set(watchlists.flatMap((w) => w.target_subreddits))
      );
      const allKeywords = Array.from(
        new Set(watchlists.flatMap((w) => w.keywords))
      );
      const allCompetitors = Array.from(
        new Set(watchlists.flatMap((w) => w.competitors))
      );

      const redditPosts = await collectRedditSignals(allSubs, allKeywords);
      const socialPosts = await collectSocialSearchSignals(
        allCompetitors,
        allKeywords
      );
      const combined = [...redditPosts, ...socialPosts];

      if (combined.length > 0) {
        await supabaseAdmin.from("raw_posts").upsert(
          combined.map((p) => ({
            source_platform: p.source_platform,
            external_id: p.id,
            source_url: p.source_url,
            author_handle: p.author_handle,
            post_title: p.post_title || null,
            post_body: p.post_body,
            published_at: p.published_at,
            dedup_hash: p.dedup_hash,
            processed: false,
          })),
          { onConflict: "dedup_hash", ignoreDuplicates: true }
        );
      }

      return combined.length;
    });

    // Step 3: Fetch unprocessed posts from DB
    const unprocessedPosts = await step.run("fetch-unprocessed", async () => {
      const { data } = await supabaseAdmin
        .from("raw_posts")
        .select("*")
        .eq("processed", false)
        .order("created_at", { ascending: false })
        .limit(15);
      return data || [];
    });

    if (unprocessedPosts.length === 0) {
      return { discoveredCount, processedCount: 0 };
    }

    // Step 4: Tier 1 Binary Noise Filter (Gemini 1.5 Flash)
    const qualifiedPostIds = await step.run("tier-1-noise-gate", async () => {
      return filterNoiseBatch(unprocessedPosts);
    });

    // Step 5: Tier 2 Deep Scoring & Anti-Slop Outreach Generation
    const leadsCreated = await step.run("tier-2-score-and-draft", async () => {
      let created = 0;

      for (const post of unprocessedPosts) {
        const isLead = qualifiedPostIds.includes(post.id);

        if (!isLead) {
          await supabaseAdmin
            .from("raw_posts")
            .update({ processed: true, is_noise: true })
            .eq("id", post.id);
          continue;
        }

        for (const wl of watchlists) {
          const scored = await scoreAndDraftOutreach(post, wl);
          if (scored.intent_score >= 60) {
            await supabaseAdmin.from("qualified_leads").insert({
              watchlist_id: wl.id,
              user_id: wl.user_id,
              raw_post_id: post.id,
              ...scored,
            });
            created++;

            if (scored.intent_score >= 85 && wl.slack_webhook_url) {
              await sendInstantWebhookAlert(wl.slack_webhook_url, scored, post);
            }
          }
        }

        await supabaseAdmin
          .from("raw_posts")
          .update({ processed: true, is_noise: false })
          .eq("id", post.id);
      }

      return created;
    });

    // Step 6: Prune 7-day-old noise posts to keep 500MB free Supabase DB lean
    await step.run("prune-old-noise", async () => {
      await supabaseAdmin.rpc("prune_old_noise_posts");
    });

    return {
      discoveredCount,
      evaluatedCount: unprocessedPosts.length,
      leadsCreated,
    };
  }
);
