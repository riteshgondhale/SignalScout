import { NextResponse } from "next/server";
import { supabaseAdmin, isSupabaseConfigured } from "@/lib/supabase";

/**
 * Feedback & Status Updater:
 * When a user marks a lead as "dismissed" with a feedback reason or negative keyword,
 * it automatically appends the negative keyword to their Watchlist to prevent future noise.
 */
export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { leadId, status, feedbackReason, negativeKeyword, watchlistId } = body;

    if (!leadId || !status) {
      return NextResponse.json(
        { error: "leadId and status are required" },
        { status: 400 }
      );
    }

    if (!isSupabaseConfigured()) {
      return NextResponse.json({
        updated: true,
        leadId,
        status,
        addedNegativeKeyword: negativeKeyword || null,
        mode: "demo_local",
      });
    }

    const { error } = await supabaseAdmin
      .from("qualified_leads")
      .update({
        status,
        feedback_reason: feedbackReason || null,
      })
      .eq("id", leadId);

    if (error) throw error;

    // If user dismissed the lead and supplied a negative keyword, append it to their watchlist
    if (status === "dismissed" && negativeKeyword && watchlistId) {
      const { data: wl } = await supabaseAdmin
        .from("watchlists")
        .select("negative_keywords")
        .eq("id", watchlistId)
        .single();

      if (wl) {
        const updatedNegatives = Array.from(
          new Set([...(wl.negative_keywords || []), negativeKeyword.toLowerCase().trim()])
        );
        await supabaseAdmin
          .from("watchlists")
          .update({ negative_keywords: updatedNegatives })
          .eq("id", watchlistId);
      }
    }

    return NextResponse.json({
      updated: true,
      leadId,
      status,
      addedNegativeKeyword: negativeKeyword || null,
    });
  } catch (err) {
    console.error("[Lead Feedback API Error]:", err);
    return NextResponse.json(
      { error: "Failed to update lead status" },
      { status: 500 }
    );
  }
}
