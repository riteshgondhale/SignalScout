import { NextResponse } from "next/server";
import { generateWatchlistFromInput } from "@/lib/gemini";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const userInput = (body?.input || "").trim();

    if (!userInput || userInput.length < 10) {
      return NextResponse.json(
        { error: "Please provide a website URL or a 1-2 sentence description of your offer." },
        { status: 400 }
      );
    }

    // Fallback smart profile if GEMINI_API_KEY isn't set yet during local test
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.includes("YourGeminiApiKey")) {
      return NextResponse.json({
        profile: {
          title: "B2B SaaS & Consulting Monitor",
          offer_summary: userInput,
          target_audiences: [
            "SaaS Founders",
            "Agency Owners",
            "E-commerce Directors",
            "Technical Leads",
          ],
          competitors: ["AiSDR", "Traxy.ai", "Apollo.io", "Clay", "Waalaxy"],
          keywords: [
            "looking for a",
            "alternative to",
            "too expensive",
            "recommend a tool",
            "struggling with outbound",
            "warm leads",
            "need a freelancer",
          ],
          negative_keywords: [
            "[for hire]",
            "hiring intern",
            "my course",
            "free pdf",
            "looking for full-time job",
          ],
          target_subreddits: [
            "SaaS",
            "entrepreneur",
            "smallbusiness",
            "webdev",
            "freelance",
          ],
        },
        mode: "demo_fallback",
      });
    }

    const profile = await generateWatchlistFromInput(userInput);
    return NextResponse.json({ profile, mode: "gemini_live" });
  } catch (error) {
    console.error("[Onboarding API Error]:", error);
    return NextResponse.json(
      { error: "Failed to generate monitoring profile. Check your GEMINI_API_KEY." },
      { status: 500 }
    );
  }
}
