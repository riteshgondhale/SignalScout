import { serve } from "inngest/next";
import { inngest, processIncomingSocialSignals } from "@/inngest/functions";

export const { GET, POST, PUT } = serve({
  client: inngest,
  functions: [processIncomingSocialSignals],
});
