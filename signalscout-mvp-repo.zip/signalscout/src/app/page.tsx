"use client";

import React, { useState } from "react";
import { INITIAL_DEMO_LEADS, DemoLead } from "@/lib/demo-data";
import {
  Flame,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  Filter,
  ThumbsDown,
  Plus,
  Radar,
  ShieldCheck,
  MessageSquare,
  Send,
  HelpCircle,
  RefreshCw,
} from "lucide-react";

export default function SignalScoutDashboard() {
  const [leads, setLeads] = useState<DemoLead[]>(INITIAL_DEMO_LEADS);
  const [platformFilter, setPlatformFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("new");
  const [activeDraftTab, setActiveDraftTab] = useState<
    Record<string, "public" | "dm" | "question">
  >({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // 60-Second Onboarding Modal State
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [onboardingInput, setOnboardingInput] = useState<string>("");
  const [isGeneratingProfile, setIsGeneratingProfile] = useState<boolean>(false);
  const [watchlistProfile, setWatchlistProfile] = useState({
    title: "B2B SaaS & Consulting Signals",
    offer_summary:
      "Find high-intent leads across Reddit, X, and LinkedIn with human-in-the-loop contextual replies.",
    competitors: ["AiSDR", "Traxy.ai", "Apollo.io", "Clay"],
    keywords: [
      "looking for a",
      "alternative to",
      "too expensive",
      "need a freelancer",
      "recommend a tool",
    ],
    negative_keywords: ["[for hire]", "hiring intern", "my course"],
    target_subreddits: ["SaaS", "webdev", "entrepreneur", "smallbusiness"],
  });

  const filteredLeads = leads.filter((lead) => {
    if (platformFilter !== "all" && lead.source_platform !== platformFilter)
      return false;
    if (statusFilter !== "all" && lead.status !== statusFilter) return false;
    return true;
  });

  const handleCopyDraft = (lead: DemoLead) => {
    const mode = activeDraftTab[lead.id] || "public";
    const text =
      mode === "public"
        ? lead.draft_public_reply
        : mode === "dm"
        ? lead.draft_private_dm
        : lead.draft_question;

    navigator.clipboard.writeText(text);
    setCopiedId(lead.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleMarkContacted = async (leadId: string, url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, status: "contacted" } : l))
    );
    await fetch("/api/leads/feedback", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ leadId, status: "contacted" }),
    });
  };

  const handleDismissLead = async (leadId: string, reason: string) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, status: "dismissed" } : l))
    );
    setWatchlistProfile((prev) => ({
      ...prev,
      negative_keywords: Array.from(
        new Set([...prev.negative_keywords, reason.toLowerCase()])
      ),
    }));
    await fetch("/api/leads/feedback", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        leadId,
        status: "dismissed",
        feedbackReason: reason,
        negativeKeyword: reason,
      }),
    });
  };

  const handleGenerateOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onboardingInput.trim()) return;
    setIsGeneratingProfile(true);
    try {
      const res = await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input: onboardingInput }),
      });
      const data = await res.json();
      if (data?.profile) {
        setWatchlistProfile(data.profile);
        setShowOnboarding(false);
      }
    } finally {
      setIsGeneratingProfile(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navigation */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Radar className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white">
                  SignalScout
                </span>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  Gemini 1.5 Flash Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Zero-Cookie Social Intent Listener & Anti-Slop Outreach Studio
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span>100% Public Signals (Ban-Proof)</span>
            </div>
            <button
              onClick={() => setShowOnboarding(true)}
              className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs sm:text-sm px-3.5 py-2 rounded-lg transition"
            >
              <Sparkles className="h-4 w-4" />
              <span>60s AI Setup Wizard</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        {/* Left Sidebar: Active Monitor Configuration */}
        <aside className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-sm text-white flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                Active Signal Monitor
              </h2>
              <button
                onClick={() => setShowOnboarding(true)}
                className="text-xs text-emerald-400 hover:underline"
              >
                Edit Offer
              </button>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                Watchlist Name
              </div>
              <div className="text-sm font-semibold text-slate-100 mt-0.5">
                {watchlistProfile.title}
              </div>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {watchlistProfile.offer_summary}
              </p>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400 mb-1.5">
                Monitored Subreddits & Channels
              </div>
              <div className="flex flex-wrap gap-1.5">
                {watchlistProfile.target_subreddits.map((sub) => (
                  <span
                    key={sub}
                    className="text-xs bg-orange-500/10 text-orange-300 border border-orange-500/20 px-2 py-0.5 rounded-md"
                  >
                    r/{sub}
                  </span>
                ))}
                <span className="text-xs bg-sky-500/10 text-sky-300 border border-sky-500/20 px-2 py-0.5 rounded-md">
                  X Search Dorks
                </span>
                <span className="text-xs bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded-md">
                  LinkedIn Posts
                </span>
              </div>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400 mb-1.5">
                Competitor Churn Triggers
              </div>
              <div className="flex flex-wrap gap-1.5">
                {watchlistProfile.competitors.map((comp) => (
                  <span
                    key={comp}
                    className="text-xs bg-slate-800 text-slate-200 px-2 py-0.5 rounded-md"
                  >
                    {comp}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400 mb-1.5">
                High-Intent Phrase Triggers
              </div>
              <div className="flex flex-wrap gap-1.5">
                {watchlistProfile.keywords.map((kw) => (
                  <span
                    key={kw}
                    className="text-xs bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded-md"
                  >
                    &ldquo;{kw}&rdquo;
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400 mb-1.5">
                Auto-Tuned Negative Filters (Noise Gate)
              </div>
              <div className="flex flex-wrap gap-1.5">
                {watchlistProfile.negative_keywords.map((neg) => (
                  <span
                    key={neg}
                    className="text-xs bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded-md"
                  >
                    -{neg}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* $0 Free-Tier Telemetry Box */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2.5">
            <div className="text-xs font-semibold text-slate-200">
              $0 Bootstrap Infrastructure Status
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                <div className="text-slate-400">Tier 1 Noise Filtered</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5">
                  89.4%
                </div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                <div className="text-slate-400">Gemini Free Quota</div>
                <div className="text-base font-bold text-slate-100 mt-0.5">
                  42 / 1,500 RPD
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Right Column: Warm Lead Feed */}
        <main className="lg:col-span-8 space-y-4">
          {/* Filter Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5">
              <Filter className="h-4 w-4 text-slate-400 mr-1" />
              {(["all", "reddit", "x", "linkedin"] as const).map((plat) => (
                <button
                  key={plat}
                  onClick={() => setPlatformFilter(plat)}
                  className={`text-xs font-medium px-2.5 py-1.5 rounded-lg transition ${
                    platformFilter === plat
                      ? "bg-emerald-500 text-slate-950 font-semibold"
                      : "bg-slate-800/70 text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  {plat === "all"
                    ? "All Platforms"
                    : plat === "x"
                    ? "X / Twitter"
                    : plat.charAt(0).toUpperCase() + plat.slice(1)}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              {(["new", "contacted", "dismissed", "all"] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`text-xs px-2.5 py-1.5 rounded-lg capitalize transition ${
                    statusFilter === st
                      ? "bg-slate-200 text-slate-950 font-semibold"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Lead Cards */}
          {filteredLeads.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-10 text-center space-y-2">
              <p className="text-sm text-slate-300 font-medium">
                No leads matching current filter.
              </p>
              <p className="text-xs text-slate-500">
                Switch status filter to &ldquo;All&rdquo; or run the 60s AI Setup Wizard to scan new topics.
              </p>
            </div>
          ) : (
            filteredLeads.map((lead) => {
              const currentTab = activeDraftTab[lead.id] || "public";
              const draftText =
                currentTab === "public"
                  ? lead.draft_public_reply
                  : currentTab === "dm"
                  ? lead.draft_private_dm
                  : lead.draft_question;

              return (
                <div
                  key={lead.id}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 space-y-4 transition"
                >
                  {/* Lead Card Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-semibold px-2.5 py-0.5 rounded-md uppercase ${
                          lead.source_platform === "reddit"
                            ? "bg-orange-500/15 text-orange-300 border border-orange-500/30"
                            : lead.source_platform === "x"
                            ? "bg-sky-500/15 text-sky-300 border border-sky-500/30"
                            : "bg-blue-500/15 text-blue-300 border border-blue-500/30"
                        }`}
                      >
                        {lead.subreddit || lead.source_platform}
                      </span>
                      <span className="text-xs font-medium text-slate-300">
                        {lead.author_handle}
                      </span>
                      <span className="text-xs text-slate-500">
                        • {lead.published_ago}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-medium">
                        {lead.intent_category.replace("_", " ")}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                        <Flame className="h-3.5 w-3.5 text-emerald-400" />
                        {lead.intent_score}% Fit
                      </span>
                    </div>
                  </div>

                  {/* Extracted Pain Summary & Post Content */}
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-emerald-400">
                      Detected Pain Point: {lead.extracted_pain_point}
                    </div>
                    <h3 className="text-base font-semibold text-white">
                      {lead.post_title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {lead.post_body}
                    </p>
                    <div className="bg-amber-500/10 border-l-2 border-amber-400 px-3 py-2 rounded-r-lg text-xs text-amber-200 italic">
                      &ldquo;{lead.highlighted_quote}&rdquo;
                    </div>
                  </div>

                  {/* Contextual Response Studio */}
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                      <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                        <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
                        Anti-Slop Outreach Studio
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() =>
                            setActiveDraftTab((prev) => ({
                              ...prev,
                              [lead.id]: "public",
                            }))
                          }
                          className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition ${
                            currentTab === "public"
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          <MessageSquare className="h-3 w-3" />
                          Helpful Thread Reply
                        </button>
                        <button
                          onClick={() =>
                            setActiveDraftTab((prev) => ({
                              ...prev,
                              [lead.id]: "dm",
                            }))
                          }
                          className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition ${
                            currentTab === "dm"
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          <Send className="h-3 w-3" />
                          Direct DM Hook
                        </button>
                        <button
                          onClick={() =>
                            setActiveDraftTab((prev) => ({
                              ...prev,
                              [lead.id]: "question",
                            }))
                          }
                          className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition ${
                            currentTab === "question"
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          <HelpCircle className="h-3 w-3" />
                          Diagnostic Question
                        </button>
                      </div>
                    </div>

                    <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-mono bg-slate-900/90 p-3 rounded-lg border border-slate-800/80">
                      {draftText}
                    </p>

                    {/* Action Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopyDraft(lead)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-100 px-3 py-1.5 rounded-lg transition"
                        >
                          {copiedId === lead.id ? (
                            <>
                              <Check className="h-3.5 w-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-3.5 w-3.5" />
                              <span>Copy Draft</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() =>
                            handleMarkContacted(lead.id, lead.source_url)
                          }
                          className="inline-flex items-center gap-1.5 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3 py-1.5 rounded-lg transition"
                        >
                          <span>Open Post & Reply</span>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={() =>
                          handleDismissLead(lead.id, "irrelevant_audience")
                        }
                        className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-rose-400 px-2 py-1 rounded transition"
                        title="Dismiss & train negative keyword filter"
                      >
                        <ThumbsDown className="h-3.5 w-3.5" />
                        <span>Bad Lead (Train Filter)</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </main>
      </div>

      {/* 60-Second Onboarding Modal */}
      {showOnboarding && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">
                  60-Second AI Monitor Setup
                </h3>
              </div>
              <button
                onClick={() => setShowOnboarding(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close ✕
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              No complex Boolean queries needed. Paste your website URL or describe what you sell in 1–2 sentences. Gemini 1.5 Flash will extract your ideal buyers, competitors, subreddits, and negative noise filters.
            </p>

            <form onSubmit={handleGenerateOnboarding} className="space-y-4">
              <textarea
                rows={4}
                value={onboardingInput}
                onChange={(e) => setOnboardingInput(e.target.value)}
                placeholder="Example: I run a boutique agency that migrates Shopify Plus stores to Checkout Extensibility and fixes site speed bottlenecks for 7-figure DTC brands."
                className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                required
              />

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowOnboarding(false)}
                  className="text-xs text-slate-400 hover:text-slate-200 px-3 py-2"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGeneratingProfile}
                  className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-semibold text-xs sm:text-sm px-4 py-2 rounded-lg transition"
                >
                  {isGeneratingProfile ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Generating with Gemini...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" />
                      <span>Generate Watchlist Rules</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
