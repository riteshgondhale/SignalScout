import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SignalScout — Open-Source Social Intent Lead Finder (Gemini 1.5 Flash)",
  description:
    "Convert real-time buyer pain signals on Reddit, X, and LinkedIn into warm leads with non-cringe outreach drafts.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased selection:bg-emerald-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
